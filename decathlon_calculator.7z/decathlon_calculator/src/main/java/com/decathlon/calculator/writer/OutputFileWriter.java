package com.decathlon.calculator.writer;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.PersonalResult;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Holds output data formatting and create output file functionality.
 *
 * @author Julius Kavaliauskas
 */
public class OutputFileWriter {

    public List<PersonalResult> orderResults(CompetitionResults results) {
        List<PersonalResult> orderedList = new ArrayList<>();
        int place = 1;
        while (true) {
            List<PersonalResult> winners = retrievePlaceWinners(results.getCompetitionResults(), place);
            for (PersonalResult winner : winners) {
                orderedList.add(winner);
            }
            if (winners.size() == 0) {
                return orderedList;
            }
            place = getMaxPlace(winners.get(0).getPlaces()) + 1;
        }
    }

    public String toString(String[] values) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            builder.append(values[i]);
            if (i < values.length - 1) {
                builder.append(";");
            }
        }
        return builder.toString();
    }

    public String toString(int[] values) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            builder.append(values[i]);
            if (i < values.length - 1) {
                builder.append(";");
            }
        }
        return builder.toString();
    }

    public void writeToFile(String fileName, String fileContent) {
        try {
            File file = new File(fileName);
            if (file.exists()) {
                throw new RuntimeException("File " + fileName + " already exists.");
            }

            File pathnameParent = file.getParentFile();
            if (pathnameParent != null) {
                pathnameParent.mkdirs();
            }

            FileOutputStream fop = new FileOutputStream(file);
            String createdFileAbsolutePath = file.getAbsolutePath();

            byte[] contentInBytes = fileContent.getBytes();
            fop.write(contentInBytes);
            fop.flush();
            fop.close();

            System.out.println("Output file " + createdFileAbsolutePath + " is created.");

        } catch (IOException e) {
            throw new RuntimeException("System error when writing data to output file");
        }
    }

    private int getMaxPlace(int[] places) {
        int maxPlace = 0;
        for (int place : places) {
            if (place > maxPlace) {
                maxPlace = place;
            }
        }
        return maxPlace;
    }

    private List<PersonalResult> retrievePlaceWinners(PersonalResult[] personalResults, int placeToRetrieve) {
        List<PersonalResult> winners = new ArrayList<>();
        for (PersonalResult personalResult : personalResults) {
            int[] places = personalResult.getPlaces();
            for (int place : places) {
                if (place == placeToRetrieve) {
                    winners.add(personalResult);
                }
            }
        }
        return winners;
    }

}