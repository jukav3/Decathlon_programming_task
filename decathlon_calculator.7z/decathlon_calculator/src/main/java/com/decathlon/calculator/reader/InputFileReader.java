package com.decathlon.calculator.reader;

import com.decathlon.calculator.data.PersonalResult;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Input file reader.
 *
 * @author Julius Kavaliauskas
 */
public class InputFileReader {

    public String[] readFileData(String fileName) {
        try {
            InputStream inputStream = new FileInputStream(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            List<String> lines = new ArrayList<>();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    return lines.toArray(new String[]{});
                }
                lines.add(line);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Invalid file path or file name");
        } catch (IOException e) {
            throw new RuntimeException("Error when reading input file");
        }
    }

    public PersonalResult assemblePersonalResult(String[] lineValues) {
        if (lineValues == null || lineValues.length == 0) {
            return null;
        }
        PersonalResult score = new PersonalResult();
        score.setName(lineValues[0]);
        String[] results = new String[lineValues.length - 1];
        for (int i = 1; i < lineValues.length; i++) {
            results[i-1] = lineValues[i];
        }
        score.setResults(results);
        return score;
    }

}
