package com.decathlon.calculator;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.reader.InputDataParser;
import com.decathlon.calculator.reader.ResultsDigitsParser;
import com.decathlon.calculator.reader.ResultsDigitsParserImpl;
import com.decathlon.calculator.writer.OutputBuilder;

/**
 * Decathlon calculator command.
 *
 * @author Julius Kavaliauskas
 */
public class DecathlonCalculatorCommand {

    private String inputFileName;
    private String outputFileName;
    private InputDataParser parser;
    private OutputBuilder outputDataBuilder;

    public DecathlonCalculatorCommand(String inputFileName, String outputFileName, InputDataParser parser, OutputBuilder outputDataBuilder) {
        this.inputFileName = inputFileName;
        this.outputFileName = outputFileName;
        this.parser = parser;
        this.outputDataBuilder = outputDataBuilder;
    }

    public void execute() {

        CompetitionResults competitionResults = parser.parseData(inputFileName);

        ResultsDigitsParser resultsDigitsParser = new ResultsDigitsParserImpl();
        DecathlonResultsCalculator calculator = new DecathlonResultsCalculator(resultsDigitsParser);
        competitionResults = calculator.calculateResults(competitionResults);

        outputDataBuilder.createOutputFile(competitionResults, outputFileName);
    }

}
