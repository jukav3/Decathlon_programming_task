package com.decathlon.calculator.reader;

import java.math.BigDecimal;

/**
 * Interface of input data value parser and formatter to number values ready for score calculation.
 *
 * @author Julius Kavaliauskas
 */
public interface ResultsDigitsParser {

    BigDecimal[] resultsToNumbers(String[] results);

}