package com.decathlon.calculator.data;

/**
 * Competition results data holder.
 *
 * @author Julius Kavaliauskas
 */
public class CompetitionResults {

    private PersonalResult[] competitionResults;

    public PersonalResult[] getCompetitionResults() {
        return competitionResults;
    }

    public void setCompetitionResults(PersonalResult[] competitionResults) {
        this.competitionResults = competitionResults;
    }
}
