package com.decathlon.calculator.reader;

import com.decathlon.calculator.data.DecathlonEvents;
import com.decathlon.calculator.data.Metric;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * Results input data parser implementation.
 *
 * @author Julius Kavaliauskas
 */
public class ResultsDigitsParserImpl implements ResultsDigitsParser {

    public BigDecimal[] resultsToNumbers(String[] results) {
        if (results == null || results.length != 10) {
            String length = (results == null) ? "no" : String.valueOf(results.length);
            throw new RuntimeException("Input data contains " + length + " positions results when 10 is expected");
        }
        BigDecimal[] resultsInNumbers = new BigDecimal[10];
        for (int i = 0; i < results.length; i++) {
            resultsInNumbers[i] = toNumber(results[i], getMetric(i));
        }
        return resultsInNumbers;
    }

    private BigDecimal toNumber(String value, Metric metric) throws NumberFormatException {
        final String EVENT_RESULT_VALUE_SEPARATOR_REGEX = "\\.";

        if (value == null || value.trim().length() == 0) {
            return null;
        }

        String[] parts = value.split(EVENT_RESULT_VALUE_SEPARATOR_REGEX);

        if (metric == Metric.METRES || metric == Metric.CENTIMETRES) {
            return getMetricValue(value, metric, parts);
        }
        // Calculating time value in seconds:
        return getSecondsValue(value, parts);
    }

    private BigDecimal getMetricValue(String value, Metric metric, String[] parts) {
        if (metric == Metric.METRES) {
            if (parts.length > 2) {
                throw new NumberFormatException("There is invalid event result in input data where meters are expected: " + value);
            }
            return new BigDecimal(value.trim());
        }
        // Calculating centimeters
        if (parts.length > 2) {
            throw new NumberFormatException("There is invalid event result in input data where meters or centimeters are expected: " + value);
        }
        if (parts.length == 2) { //Meters with centimeters.
            int centimeters = Integer.valueOf(parts[0].trim()) * 100 + Integer.valueOf(parts[1].trim());
            return new BigDecimal(String.valueOf(centimeters));
        }
        return new BigDecimal(value.trim()); // Centimeters.
    }

    private BigDecimal getSecondsValue(String value, String[] parts) {
        if (parts.length == 1 || parts.length > 3) {
            throw new NumberFormatException("There is invalid event result in input data where time is expected: " + value);
        }
        if (parts.length == 2) { //Seconds with milliseconds.
            return new BigDecimal(value.trim());
        }
        if (parts.length == 3) { //Minutes with seconds and milliseconds.
            DecimalFormat df = new DecimalFormat( "000" );
            double secondsWithMilliseconds = Double.valueOf(parts[0].trim()) * 60 + Double.valueOf(parts[1].trim()) + Double.valueOf("0." + parts[2].trim());
            return new BigDecimal(String.valueOf(secondsWithMilliseconds));
        }
        return null;
    }

    private Metric getMetric(int position) {
        for (DecathlonEvents event : DecathlonEvents.values()) {
            if (position == event.getPosition()) {
                return event.getMetric();
            }
        }
        throw new RuntimeException("System error - expected position not found in decathlon events data.");
    }

}