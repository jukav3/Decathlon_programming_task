package com.decathlon.calculator;

import com.decathlon.calculator.reader.CSVDataParser;
import com.decathlon.calculator.reader.InputDataParser;
import com.decathlon.calculator.writer.OutputBuilder;
import com.decathlon.calculator.writer.XmlDataBuilder;

import java.util.Scanner;

/**
 * Main class for running decathlon calculator.
 *
 * @author Julius Kavaliauskas
 */
public class Application {

    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);

            String inputFileName = readInputFileName(scanner);
            InputDataParser inputDataParser = getInputDataParser(inputFileName);

            String outputFileName = readOutputFileName(scanner);
            OutputBuilder outputBuilder = getOutputBuilder(outputFileName);

            DecathlonCalculatorCommand calculatorCommand = new DecathlonCalculatorCommand(inputFileName, outputFileName, inputDataParser, outputBuilder);
            calculatorCommand.execute();

        } catch (Throwable e) {
            System.out.println("Error: " + e.getMessage());
            //e.printStackTrace();
        }
    }

    private static String readInputFileName(Scanner scanner) {
        System.out.print("Enter input file name, e.g, C:/folder/Decathlon_input.txt : ");
        return scanner.next();
    }

    private static String readOutputFileName(Scanner scanner) {
        System.out.print("Enter output file name, e.g, C:/folder/Decathlon_output.xml : ");
        return scanner.next();
    }

    private static InputDataParser getInputDataParser(String inputFileName) {
        String fileExtension = getFileExtension(inputFileName);
        if ("txt".equalsIgnoreCase(fileExtension) || fileExtension == null) {
            return new CSVDataParser();
        }
        throw new RuntimeException("Input file extension ." + fileExtension + " is not supported.");
    }

    private static OutputBuilder getOutputBuilder(String outputFileName) {
        String fileExtension = getFileExtension(outputFileName);
        if ("xml".equalsIgnoreCase(fileExtension) || fileExtension == null) {
            return new XmlDataBuilder();
        }
        throw new RuntimeException("Output file extension ." + fileExtension + " is not supported.");
    }

    public static String getFileExtension(String fileName) {
        int i = fileName.lastIndexOf(".");
        if (i >= 0) {
            return fileName.substring(i + 1);
        }
        return null;
    }

}