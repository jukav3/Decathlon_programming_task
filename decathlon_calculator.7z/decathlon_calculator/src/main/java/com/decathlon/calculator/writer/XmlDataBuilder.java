package com.decathlon.calculator.writer;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.PersonalResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.util.List;

/**
 * XML type output file builder implementation.
 *
 * @author Julius Kavaliauskas
 */
public class XmlDataBuilder extends OutputFileWriter implements OutputBuilder {

    public void createOutputFile(CompetitionResults results, String outputFileName) {
        Document doc = createDocument();
        Element mainRootElement = doc.createElement("Decathlon");
        //Element mainRootElement = doc.createElementNS("https://crunchify.com/CrunchifyCreateXMLDOM", "Companies");
        doc.appendChild(mainRootElement);

        List<PersonalResult> orderedList = orderResults(results);
        for (PersonalResult participant : orderedList) {
            mainRootElement.appendChild(addParticipant(participant, doc));
        }
        writeToFile(outputFileName, toFileContent(doc));
    }

    private Node addParticipant(PersonalResult result, Document doc) {
        Element element = doc.createElement("Participant");
        element.setAttribute("name", result.getName());
        element.appendChild(createElement("Place", toString(result.getPlaces()), doc));
        element.appendChild(createElement("Score", String.valueOf(result.getScore()), doc));
        element.appendChild(createElement("Results", toString(result.getResults()), doc));
        return element;
    }

    private Node createElement(String name, String value, Document doc) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }

    private Document createDocument() {
        try {
            DocumentBuilderFactory icFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder icBuilder = icFactory.newDocumentBuilder();
            return icBuilder.newDocument();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("Error when creating XML");
        }
    }

    private String toFileContent(Document doc) {
        try {
            DOMSource domSource = new DOMSource(doc);
            //Consider to use ByteArrayOutputStream streamOut = new ByteArrayOutputStream(); to provide to file ouptut
            // https://www.programcreek.com/java-api-examples/?class=javax.xml.transform.Transformer&method=transform
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.transform(domSource, result);
            return writer.toString();
        } catch (TransformerException e) {
            throw new RuntimeException("Error when creating XML");
        }
    }

}