package com.decathlon.calculator.reader;

import com.decathlon.calculator.data.CompetitionResults;

/**
 * Input data parser interface.
 *
 * @author Julius Kavaliauskas
 */
public interface InputDataParser {

    CompetitionResults parseData(String inputFileName);

}
