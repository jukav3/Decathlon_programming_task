package com.decathlon.calculator.writer;

import com.decathlon.calculator.data.CompetitionResults;

/**
 * Output file builder interface.
 *
 * @author Julius Kavaliauskas
 */
public interface OutputBuilder {

    void createOutputFile(CompetitionResults results, String outputFileName);

}
