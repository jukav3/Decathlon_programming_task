package com.decathlon.calculator.data;

import java.math.BigDecimal;

import static com.decathlon.calculator.data.Metric.CENTIMETRES;
import static com.decathlon.calculator.data.Metric.METRES;
import static com.decathlon.calculator.data.Metric.SECONDS;

/**
 * Decathlon events details.
 *
 * @author Julius Kavaliauskas
 */
public enum DecathlonEvents {

    EVENT_100m(new BigDecimal("25.4347"), new BigDecimal("18"), new BigDecimal("1.81"), 0, SECONDS),
    EVENT_LONG_JUMP(new BigDecimal("0.14354"), new BigDecimal("220"), new BigDecimal("1.4"), 1, CENTIMETRES),
    EVENT_SHOT_PUT(new BigDecimal("51.39"), new BigDecimal("1.5"), new BigDecimal("1.05"), 2, METRES),
    EVENT_HIGH_JUMP(new BigDecimal("0.8465"), new BigDecimal("75"), new BigDecimal("1.42"), 3, CENTIMETRES),
    EVENT_400m(new BigDecimal("1.53775"), new BigDecimal("82"), new BigDecimal("1.81"), 4, SECONDS),
    EVENT_110m_HURDLES(new BigDecimal("5.74352"), new BigDecimal("28.5"), new BigDecimal("1.92"), 5, SECONDS),
    EVENT_DISCUS_THROW(new BigDecimal("12.91"), new BigDecimal("4"), new BigDecimal("1.1"), 6, METRES),
    EVENT_POLE_VAULT(new BigDecimal("0.2797"), new BigDecimal("100"), new BigDecimal("1.35"), 7, CENTIMETRES),
    EVENT_JAVELIN_THROW(new BigDecimal("10.14"), new BigDecimal("7"), new BigDecimal("1.08"), 8, METRES),
    EVENT_1500m(new BigDecimal("0.03768"), new BigDecimal("480"), new BigDecimal("1.85"), 9, SECONDS);

    private BigDecimal a; //Value of A in track or field event points formula.
    private BigDecimal b; //Value of B in track or field event points formula.
    private BigDecimal c; //Value of C in track or field event points formula.
    private int position; //Expected position of the result in input data.
    private Metric metric; //How the result is measured, e.g., seconds.

    DecathlonEvents(BigDecimal a, BigDecimal b, BigDecimal c, int position, Metric metric) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.position = position;
        this.metric = metric;
    }

    public BigDecimal getB() {
        return b;
    }

    public BigDecimal getC() {
        return c;
    }

    public BigDecimal getA() {
        return a;
    }

    public int getPosition() {
        return position;
    }

    public Metric getMetric() {
        return metric;
    }
}
