package com.decathlon.calculator.data;

/**
 * Metric used for decathlon results.
 *
 * @author Julius Kavaliauskas
 */
public enum Metric {
    SECONDS, METRES, CENTIMETRES;
}