package com.decathlon.calculator.data;

/**
 * Decathlon competition participant result data holder.
 *
 * @author Julius Kavaliauskas
 */
public class PersonalResult {

    private String name;

    private String[] results;

    private int[] places;

    private int score;

    public String[] getResults() {
        return results;
    }

    public void setResults(String[] results) {
        this.results = results;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int[] getPlaces() {
        return places;
    }

    public void setPlaces(int[] places) {
        this.places = places;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}