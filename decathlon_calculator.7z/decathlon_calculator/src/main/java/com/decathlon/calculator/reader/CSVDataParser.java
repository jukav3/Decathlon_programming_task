package com.decathlon.calculator.reader;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.PersonalResult;

import java.util.ArrayList;
import java.util.List;

/**
 * CSV type input data parser.
 *
 * @author Julius Kavaliauskas
 */
public class CSVDataParser extends InputFileReader implements InputDataParser {

    private final String SEPARATOR = ";";

    public CompetitionResults parseData(String inputFileName) {

        String[] inputLines = readFileData(inputFileName);

        List<PersonalResult> resultsList = new ArrayList<PersonalResult>();
        for (String line : inputLines) {
            String[] lineValues = line.split(SEPARATOR);
            resultsList.add(assemblePersonalResult(lineValues));
        }

        CompetitionResults competitionResults = new CompetitionResults();
        competitionResults.setCompetitionResults(resultsList.toArray(new PersonalResult[]{}));
        return competitionResults;
    }

}
