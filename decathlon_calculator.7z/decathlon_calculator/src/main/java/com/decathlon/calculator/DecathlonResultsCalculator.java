package com.decathlon.calculator;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.DecathlonEvents;
import com.decathlon.calculator.data.Metric;
import com.decathlon.calculator.data.PersonalResult;
import com.decathlon.calculator.reader.ResultsDigitsParser;

import java.math.BigDecimal;

/**
 * Decathlon competition score and places calculator.
 *
 * @author Julius Kavaliauskas
 */
public class DecathlonResultsCalculator {

    private ResultsDigitsParser resultsValuesParser;

    public DecathlonResultsCalculator(ResultsDigitsParser resultsValuesParser) {
        this.resultsValuesParser = resultsValuesParser;
    }

    public CompetitionResults calculateResults(CompetitionResults competitionResults) {
        PersonalResult[] results = competitionResults.getCompetitionResults();
        if (results == null || results.length == 0) {
            return competitionResults;
        }
        results = calculateCompetitionPoints(results);
        Integer[] points = extractPoints(results);
        int placeToAssign = 1;
        int placeWinnerPoints = 0;
        while (placeWinnerPoints >= 0) {
            placeWinnerPoints = getMaxScore(points);
            int participantsAssigned = getNumberOfPlaceWinners(points, placeWinnerPoints);
            for (int i = 0; i < points.length; i++) {
                if (points[i] != null && points[i] == placeWinnerPoints) {
                    results[i].setPlaces(addPlaces(placeToAssign, participantsAssigned));
                    points[i] = null; // Removing to exclude from next place calculation.
                }
            }
            placeToAssign = placeToAssign + participantsAssigned;
        }
        return competitionResults;
    }

    private int calculateActivitiesPoints(BigDecimal[] results) {
        int points = 0;
        for (DecathlonEvents event : DecathlonEvents.values()) {
            BigDecimal p = results[event.getPosition()];
            if (p == null) {
                continue; //Not calculating points for the event when no result is provided.
            }
            int pp = calculateActivityPoints(event, p);
            points = points + calculateActivityPoints(event, p);
        }
        return points;
    }

    private int calculateActivityPoints(DecathlonEvents event, BigDecimal p) {
        BigDecimal a = event.getA();
        BigDecimal b = event.getB();
        BigDecimal c = event.getC();
        double d;
        if (event.getMetric() == Metric.SECONDS) { // Track event.
            d = Math.pow(b.subtract(p).doubleValue(), c.doubleValue());//(B — P)^C
        } else { // Field event, result measured in meters or centimeters.
            d = Math.pow(p.subtract(b).doubleValue(), c.doubleValue());//(P — B)^C
        }
        return multiplyAndRound(a, d);
    }

    private int multiplyAndRound(BigDecimal a, double d) {
        BigDecimal bigDecimalResult = a.multiply(BigDecimal.valueOf(d));
        return bigDecimalResult.setScale(0, BigDecimal.ROUND_DOWN).intValue();
    }

    private int getNumberOfPlaceWinners(Integer[] pointsList, int pointsForThePlace) {
        int participantsAssigned = 0;
        for (Integer points : pointsList) {
            if (points != null && points == pointsForThePlace) {
                participantsAssigned++;
            }
        }
        return participantsAssigned;
    }

    private int[] addPlaces(int placeToAssign, int participantsAssigned) {
        int[] places = new int[participantsAssigned];
        for (int i = 0; i < participantsAssigned; i++) {
            places[i] = placeToAssign + i;
        }
        return places;
    }

    private PersonalResult[] calculateCompetitionPoints(PersonalResult[] personalResults) {
        for (PersonalResult personalResult : personalResults) {
            personalResult.setScore(calculateParticipantPoints(personalResult.getResults()));
        }
        return personalResults;
    }

    private int calculateParticipantPoints(String[] results) {
        if (results == null) {
            return 0; // No results provided.
        }
        return calculateActivitiesPoints(resultsValuesParser.resultsToNumbers(results));
    }

    private int getMaxScore(Integer[] pointsList) {
        int max = -1;
        for (Integer points : pointsList) {
            if (points != null && points > max) {
                max = points;
            }
        }
        return max;
    }

    private Integer[] extractPoints(PersonalResult[] personalResults) {
        Integer[] points = new Integer[personalResults.length];
        for (int i = 0; i < personalResults.length; i++) {
            points[i] = personalResults[i].getScore();
        }
        return points;
    }

}
