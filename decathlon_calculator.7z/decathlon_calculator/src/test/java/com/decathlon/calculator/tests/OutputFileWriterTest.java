package com.decathlon.calculator.tests;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.PersonalResult;
import com.decathlon.calculator.writer.OutputFileWriter;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Holds order results for output test.
 *
 * @author Julius Kavaliauskas
 */
public class OutputFileWriterTest {

    @Test
    public void orderResultsTest() {

        CompetitionResults competitionResults = assembleCompetitionResults();

        OutputFileWriter outputFileWriter = new OutputFileWriter();
        List<PersonalResult> orderedList = outputFileWriter.orderResults(competitionResults);

        Assert.assertNotNull(orderedList);
        Assert.assertTrue(orderedList.size() == 3);
        Assert.assertTrue(orderedList.get(0).getName().equals("Siim Susi"));
        Assert.assertTrue(orderedList.get(0).getPlaces()[0] == 1);

        Assert.assertTrue(orderedList.get(1).getName().equals("Jaana Lind"));
        Assert.assertTrue(orderedList.get(1).getPlaces()[0] == 2);

        Assert.assertTrue(orderedList.get(2).getName().equals("Beata Kana"));
        Assert.assertTrue(orderedList.get(2).getPlaces()[0] == 3);
    }

    private CompetitionResults assembleCompetitionResults() {
        CompetitionResults competitionResults = new CompetitionResults();
        PersonalResult[] personalResult = new PersonalResult[3];
        personalResult[0] = assemblePersonalResult("Beata Kana", new String[]{"13.04", "4.53", "7.79", "1.55", "64.72", "18.74", "24.20", "2.40", "28.20", "6.50.76"});
        personalResult[0].setPlaces(new int[]{3});

        personalResult[1] = assemblePersonalResult("Siim Susi", new String[]{"12.61", "5.00", "9.22", "1.50", "60.39", "16.43", "21.60", "2.60", "35.81", "5.25.72"});
        personalResult[1].setPlaces(new int[]{1});

        personalResult[2] = assemblePersonalResult("Jaana Lind", new String[]{"13.75", "4.84", "10.12", "1.50", "68.44", "19.18", "30.85", "2.80", "33.88", "6.22.75"});
        personalResult[2].setPlaces(new int[]{2});
        competitionResults.setCompetitionResults(personalResult);
        return competitionResults;
    }

    private PersonalResult assemblePersonalResult(String name, String[] results) {
        PersonalResult result = new PersonalResult();
        result.setName(name);
        result.setResults(results);
        return result;
    }

}
