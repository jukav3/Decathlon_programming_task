package com.decathlon.calculator.tests;

import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.PersonalResult;
import com.decathlon.calculator.reader.CSVDataParser;
import org.junit.Assert;
import org.junit.Test;

/**
 * CSV input data parser test.
 *
 * @author Julius Kavaliauskas
 */
public class CSVDataParserTest {

    @Test
    public void parseDataTest() {
        CSVDataParser csvDataParser = new CSVDataParser();
        String inputFileName = "src//test//resources//inputTest.txt";
        CompetitionResults competitionResults = csvDataParser.parseData(inputFileName);

        Assert.assertNotNull(competitionResults);
        PersonalResult[] personalResult = competitionResults.getCompetitionResults();
        Assert.assertNotNull(personalResult.length == 4);
        Assert.assertNotNull(personalResult[0]);
        Assert.assertEquals(personalResult[0].getName(), "Siim Susi");
        Assert.assertEquals(personalResult[1].getName(), "Beata Kana");
        Assert.assertEquals(personalResult[2].getName(), "Jaana Lind");
        Assert.assertEquals(personalResult[3].getName(), "Anti Loop");
        Assert.assertEquals(personalResult[0].getResults(), new String[]{"12.61", "5.00", "9.22", "1.50", "60.39", "16.43", "21.60", "2.60", "35.81", "5.25.72 "});
        Assert.assertEquals(personalResult[1].getResults(), new String[]{"13.04", "4.53", "7.79", "1.55", "64.72", "18.74", "24.20", "2.40", "28.20", "6.50.76 "});
        Assert.assertEquals(personalResult[2].getResults(), new String[]{"13.75", "4.84", "10.12", "1.50", "68.44", "19.18", "30.85", "2.80", "33.88", "6.22.75 "});
        Assert.assertEquals(personalResult[3].getResults(), new String[]{"13.43", "4.35", "8.64", "1.50", "66.06", "19.05", "24.89", "2.20", "33.48", "6.51.01"});
    }

}