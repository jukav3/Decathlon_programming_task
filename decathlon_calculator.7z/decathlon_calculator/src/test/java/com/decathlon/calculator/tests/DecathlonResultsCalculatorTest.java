package com.decathlon.calculator.tests;

import com.decathlon.calculator.DecathlonResultsCalculator;
import com.decathlon.calculator.data.CompetitionResults;
import com.decathlon.calculator.data.PersonalResult;
import com.decathlon.calculator.reader.ResultsDigitsParser;
import com.decathlon.calculator.reader.ResultsDigitsParserImpl;
import org.junit.Assert;
import org.junit.Test;

/**
 * Decathlon competition score and places calculator test.
 *
 * @author Julius Kavaliauskas
 */
public class DecathlonResultsCalculatorTest {

    @Test
    public void calculateResultsTest() {

        ResultsDigitsParser resultsDigitsParser = new ResultsDigitsParserImpl();
        DecathlonResultsCalculator calculator = new DecathlonResultsCalculator(resultsDigitsParser);

        CompetitionResults competitionResults = assembleCompetitionResults();
        competitionResults = calculator.calculateResults(competitionResults);

        Assert.assertNotNull(competitionResults);
        PersonalResult[] personalResult = competitionResults.getCompetitionResults();
        Assert.assertNotNull(personalResult.length == 3);
        Assert.assertNotNull(personalResult[0]);
        Assert.assertNotNull(personalResult[0].getPlaces());
        Assert.assertEquals(personalResult[0].getPlaces().length, 2);
        Assert.assertEquals(personalResult[0].getPlaces()[0], 1);
        Assert.assertEquals(personalResult[0].getPlaces()[1], 2);
        Assert.assertEquals(personalResult[0].getScore(), 4200);

        Assert.assertNotNull(personalResult[1]);
        Assert.assertNotNull(personalResult[1].getPlaces());
        Assert.assertEquals(personalResult[1].getPlaces().length, 2);
        Assert.assertEquals(personalResult[1].getPlaces()[0], 1);
        Assert.assertEquals(personalResult[1].getPlaces()[1], 2);
        Assert.assertEquals(personalResult[1].getScore(), 4200);

        Assert.assertNotNull(personalResult[2]);
        Assert.assertNotNull(personalResult[2].getPlaces());
        Assert.assertEquals(personalResult[2].getPlaces().length, 1);
        Assert.assertEquals(personalResult[2].getPlaces()[0],3);
        Assert.assertEquals(personalResult[2].getScore(),3494);
    }

    private CompetitionResults assembleCompetitionResults() {
        CompetitionResults competitionResults = new CompetitionResults();
        PersonalResult[] personalResult = new PersonalResult[3];
        personalResult[0] = assemblePersonalResult("Siim Susi", new String[] {"12.61", "5.00", "9.22", "1.50", "60.39", "16.43", "21.60", "2.60", "35.81", "5.25.72"});
        personalResult[1] = assemblePersonalResult("Beata Kana",new String[] {"12.61", "5.00", "9.22", "1.50", "60.39", "16.43", "21.60", "2.60", "35.81", "5.25.72"});
        personalResult[2] = assemblePersonalResult("Jaana Lind", new String[] {"13.75","4.84", "10.12","1.50","68.44","19.18","30.85", "2.80", "33.88", "6.22.75"});
        competitionResults.setCompetitionResults(personalResult);
        return competitionResults;
    }

    private PersonalResult assemblePersonalResult(String name, String[] results) {
        PersonalResult result = new PersonalResult();
        result.setName(name);
        result.setResults(results);
        return result;
    }

}