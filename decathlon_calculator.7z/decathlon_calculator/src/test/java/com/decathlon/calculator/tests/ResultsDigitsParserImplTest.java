package com.decathlon.calculator.tests;

import com.decathlon.calculator.reader.ResultsDigitsParserImpl;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

/**
 * Results input data parser test.
 *
 * @author Julius Kavaliauskas
 */
public class ResultsDigitsParserImplTest {

    @Test
    public void resultsToNumbersTest() {
        ResultsDigitsParserImpl resultsDigitsParserImpl = new ResultsDigitsParserImpl();
        BigDecimal[] resultsInDigits = resultsDigitsParserImpl.resultsToNumbers(new String[] {"12.61", "5.00", "9.22", "1.50", "60.39", "16.43", "21.60", "2.60", "35.81", "5.25.72 "});
        Assert.assertNotNull(resultsInDigits);
        Assert.assertTrue(resultsInDigits.length == 10);
        Assert.assertTrue(resultsInDigits[0].equals(new BigDecimal("12.61")));
        Assert.assertTrue(resultsInDigits[1].equals(new BigDecimal("500")));
        Assert.assertTrue(resultsInDigits[2].equals(new BigDecimal("9.22")));
        Assert.assertTrue(resultsInDigits[3].equals(new BigDecimal("150")));
        Assert.assertTrue(resultsInDigits[4].equals(new BigDecimal("60.39")));
        Assert.assertTrue(resultsInDigits[5].equals(new BigDecimal("16.43")));
        Assert.assertTrue(resultsInDigits[6].equals(new BigDecimal("21.60")));
        Assert.assertTrue(resultsInDigits[7].equals(new BigDecimal("260")));
        Assert.assertTrue(resultsInDigits[8].equals(new BigDecimal("35.81")));
        Assert.assertTrue(resultsInDigits[9].equals(new BigDecimal("325.72")));
    }

}